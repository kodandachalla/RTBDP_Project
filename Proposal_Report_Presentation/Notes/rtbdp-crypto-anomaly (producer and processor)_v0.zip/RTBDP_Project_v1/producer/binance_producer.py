# =============================================================================
# BINANCE WEBSOCKET → KAFKA PRODUCER
# =============================================================================
# This script is Step 2 of our pipeline:
#
#   Binance WebSocket  →  [THIS FILE]  →  Kafka topic "raw-trades"
#
# What it does, step by step:
#   1. Waits for Kafka to be ready
#   2. Creates the "raw-trades" Kafka topic (if it doesn't exist yet)
#   3. Opens a WebSocket connection to Binance (no API key needed)
#   4. For every trade event received, publishes it as JSON to Kafka
#   5. Reconnects automatically if the connection drops
#   6. Prints stats every 10 seconds (how many messages sent)
#
# Run with:
#   python binance_producer.py            (full mode, writes to Kafka)
#   python binance_producer.py --dry-run  (test mode, prints to console only)
# =============================================================================


# --- Standard library imports (built into Python, no installation needed) ---

import json        # to convert Python dictionaries to JSON strings for Kafka
import time        # for time.sleep() when waiting or reconnecting
import logging     # for printing structured log messages with timestamps
import signal      # to handle Ctrl+C gracefully (flush before exit)
import sys         # to exit the program cleanly
import argparse    # to parse command-line arguments like --dry-run
from datetime import datetime, timezone  # to convert Unix timestamps to readable dates


# --- Third-party imports (installed via requirements.txt) ---

import websocket
# websocket.WebSocketApp = a class that manages a persistent WebSocket connection
# It handles reconnection, ping/pong keep-alive, and calls our callback functions

from confluent_kafka import Producer
# Producer = the Kafka client that sends (produces) messages to a topic

from confluent_kafka.admin import AdminClient, NewTopic
# AdminClient = connects to Kafka to perform admin tasks (create/delete topics)
# NewTopic    = a data class describing a topic we want to create


# =============================================================================
# LOGGING SETUP
# =============================================================================
# basicConfig sets up the global logger.
# Every log.info(), log.warning(), log.error() call uses this format.
# Output looks like: "10:42:01  INFO      WebSocket connected"
# =============================================================================

logging.basicConfig(
    level   = logging.INFO,                         # show INFO and above (not DEBUG)
    format  = "%(asctime)s  %(levelname)-8s  %(message)s",  # timestamp + level + message
    datefmt = "%H:%M:%S",                           # time format: hours:minutes:seconds
)
log = logging.getLogger("producer")  # name our logger "producer" for clarity


# =============================================================================
# CONFIGURATION CONSTANTS
# =============================================================================
# All settings in one place at the top — easy to find and change.
# In a real project these would come from environment variables or a config file.
# =============================================================================

# Where Kafka is running — "localhost" because Kafka's port 9092 is mapped
# from the Docker container to our Windows machine in docker-compose.yml
KAFKA_BOOTSTRAP = "localhost:9092"

# The name of the Kafka topic we will create and write trade events to.
# Flink will later read from this same topic.
TOPIC_NAME = "raw-trades"

# How many partitions to create for this topic.
# We use 3 — one partition per symbol (BTCUSDT, ETHUSDT, BNBUSDT).
# Partitions allow parallel processing: Flink can read all 3 simultaneously.
TOPIC_PARTITIONS = 6

# Replication factor = how many copies of each partition exist.
# We only have 1 Kafka broker, so we can only have 1 replica.
# In production with 3 brokers you would use replication_factor=3 for safety.
TOPIC_REPLICATION = 1

# How long Kafka keeps messages before deleting them (in milliseconds).
# 7_200_000 ms = 2 hours. Old trade data auto-deleted to save disk space.
# The underscore in 7_200_000 is just Python's way of writing large numbers
# more readably (like 7,200,000 with commas).
TOPIC_RETENTION_MS = 7_200_000

# The 6 crypto trading pairs we want to stream.
# These are Binance's symbol format — always lowercase for the WebSocket URL.

# 6 symbols — high volatility chosen for anomaly detection demo
SYMBOLS = ["btcusdt", "ethusdt", "bnbusdt", "solusdt", "dogeusdt", "xrpusdt"]

# Binance combined stream URL — one WebSocket connection for ALL symbols.
# Format: wss://stream.binance.com:9443/stream?streams=sym1@trade/sym2@trade/...
# The @trade suffix means "give me individual trade events" (not order book, not klines).
# This endpoint is completely free, no API key, no rate limit for WebSocket.
WS_URL = (
    "wss://stream.binance.com:9443/stream?streams="
    + "/".join(f"{s}@trade" for s in SYMBOLS)
    # f"{s}@trade" for s in SYMBOLS = ["btcusdt@trade", "ethusdt@trade", "bnbusdt@trade"]
    # "/".join(...) = "btcusdt@trade/ethusdt@trade/bnbusdt@trade"
)

# Kafka producer configuration dictionary.
# These settings control how the producer batches and sends messages.
PRODUCER_CONFIG = {
    "bootstrap.servers": KAFKA_BOOTSTRAP,  # where to find Kafka

    # acks="1" means: wait for the Kafka leader partition to confirm receipt.
    # acks="0" = fire and forget (fastest, but could lose messages)
    # acks="all" = wait for ALL replicas (slowest, most reliable)
    # For trade data, acks="1" is a good balance.
    "acks": "1",

    # linger.ms: wait up to 20ms to collect more messages before sending a batch.
    # Without this, each message is sent immediately (lots of small network calls).
    # With this, messages arriving within 20ms are batched together (more efficient).
    "linger.ms": 20,

    # batch.size: maximum size of one batch in bytes (64KB here).
    # If the batch fills up before linger.ms expires, it's sent immediately.
    "batch.size": 65536,

    # compression.type: compress messages before sending to Kafka.
    # "lz4" = very fast compression algorithm, good for high-throughput data.
    # Reduces network bandwidth and Kafka storage with minimal CPU cost.
    "compression.type": "lz4",

    # retries: if Kafka is briefly unavailable, retry up to 5 times.
    "retries": 5,

    # retry.backoff.ms: wait 500ms between retries (to not hammer a recovering Kafka).
    "retry.backoff.ms": 500,
}


# =============================================================================
# STATS TRACKER
# =============================================================================
# A simple class to track how many messages we've sent.
# Prints a summary every 10 seconds so you can see the producer is healthy.
# =============================================================================

class Stats:
    def __init__(self):
        self.total    = 0      # total messages sent since startup
        self.errors   = 0      # total delivery failures
        self.window   = 0      # messages sent in the current 10-second window
        self.last_ts  = time.time()  # when the current window started

    def tick(self):
        """Call this every time a message is successfully sent."""
        self.total  += 1
        self.window += 1
        now = time.time()

        # Every 10 seconds, print the throughput stats
        if now - self.last_ts >= 10:
            # Calculate messages per second in this window
            rate = self.window / (now - self.last_ts)
            log.info(
                f"[stats]  {self.total:>6,} total sent  |  "
                f"{rate:>5.1f} msg/s  |  "
                f"errors={self.errors}"
            )
            # Reset window counter and timestamp
            self.window  = 0
            self.last_ts = now

    def error(self):
        """Call this when Kafka reports a delivery failure."""
        self.errors += 1


# Create a single global Stats instance
stats = Stats()


# =============================================================================
# KAFKA HELPER FUNCTIONS
# =============================================================================

def wait_for_kafka(bootstrap: str, retries: int = 30, delay: int = 5) -> None:
    """
    Block and wait until Kafka is reachable.

    Why is this needed?
    On Windows, Docker containers take time to fully start.
    If the producer starts before Kafka is ready, it crashes immediately.
    This function keeps trying every 5 seconds for up to 2.5 minutes.
    """
    log.info(f"Waiting for Kafka at {bootstrap} ...")

    for attempt in range(1, retries + 1):
        try:
            # Try to create an AdminClient and list topics.
            # If this succeeds, Kafka is ready.
            admin = AdminClient({
                "bootstrap.servers": bootstrap,
                "socket.timeout.ms": 3000,   # 3 second timeout per attempt
            })
            admin.list_topics(timeout=3)     # raises exception if Kafka not ready
            log.info("✓ Kafka is ready!")
            return  # exit the function — Kafka is up

        except Exception as exc:
            # Kafka not ready yet — log and wait
            log.warning(f"  Attempt {attempt}/{retries} — not ready yet: {exc}")
            time.sleep(delay)  # wait 5 seconds before trying again

    # If we get here, all retries failed
    raise RuntimeError(
        f"Kafka at {bootstrap} did not become ready after {retries} attempts.\n"
        "Make sure Docker is running: docker compose up -d"
    )


def create_topic_if_missing(bootstrap: str) -> None:
    """
    Create the 'raw-trades' Kafka topic if it doesn't already exist.

    Why create it manually instead of using auto-create?
    We set KAFKA_AUTO_CREATE_TOPICS_ENABLE=false in docker-compose.yml
    so that Kafka never creates topics with default settings.
    By creating it manually here, we control:
      - number of partitions (3 — one per symbol)
      - retention time (2 hours — old trades auto-deleted)
      - compression (lz4)
    """
    admin    = AdminClient({"bootstrap.servers": bootstrap})
    existing = admin.list_topics(timeout=10).topics  # get dict of existing topics

    if TOPIC_NAME in existing:
        log.info(f"Topic '{TOPIC_NAME}' already exists — skipping creation.")
        return

    # Define the new topic with our custom settings
    new_topic = NewTopic(
        TOPIC_NAME,
        num_partitions     = TOPIC_PARTITIONS,    # 3 partitions
        replication_factor = TOPIC_REPLICATION,   # 1 replica (we have 1 broker)
        config             = {
            "retention.ms":     str(TOPIC_RETENTION_MS),  # 2 hour retention
            "cleanup.policy":   "delete",     # delete old segments (not compact)
            "compression.type": "lz4",        # compress stored messages
        },
    )

    # create_topics returns a dict of {topic_name: Future}
    # We call .result() on each Future to wait for completion and catch errors
    futures = admin.create_topics([new_topic])
    for topic, future in futures.items():
        try:
            future.result()  # blocks until topic creation completes or fails
            log.info(
                f"✓ Created topic '{topic}'  "
                f"(partitions={TOPIC_PARTITIONS}, retention=2h, compression=lz4)"
            )
        except Exception as exc:
            log.error(f"Failed to create topic '{topic}': {exc}")
            raise  # re-raise so the main function knows something went wrong


def delivery_report(err, msg):
    """
    Callback function called by Kafka for every message after it is sent.

    Kafka calls this asynchronously — not immediately when you call produce(),
    but later when it gets an acknowledgement from the broker.
    We only log failures to keep output clean (successes are counted in stats).

    Parameters:
        err: None if delivery succeeded, KafkaError object if it failed
        msg: the message that was delivered (or failed)
    """
    if err is not None:
        log.error(f"Delivery failed for topic={msg.topic()} key={msg.key()}: {err}")
        stats.error()
    # If err is None, delivery succeeded — stats.tick() handles the counting


def make_producer() -> Producer:
    """Create and return a configured Kafka Producer."""
    return Producer(PRODUCER_CONFIG)


# =============================================================================
# MESSAGE PARSING
# =============================================================================

def parse_binance_trade(raw: str) -> dict | None:
    """
    Parse a raw JSON string from Binance WebSocket into a clean trade dict.

    Binance sends data in this format (combined stream):
    {
      "stream": "btcusdt@trade",
      "data": {
        "e": "trade",      -- event type (always "trade" for @trade streams)
        "E": 1700000001000, -- event time in milliseconds since Unix epoch
        "s": "BTCUSDT",    -- symbol
        "t": 3482910,      -- trade ID (unique per trade on Binance)
        "p": "43210.50",   -- price AS A STRING (not a number!)
        "q": "0.00123",    -- quantity AS A STRING
        "T": 1700000001000, -- trade execution time in milliseconds
        "m": false          -- is the buyer the market maker?
                              false = buyer was aggressor (bought at ask price)
                              true  = seller was aggressor (sold at bid price)
      }
    }

    We extract only what we need and convert types (string → float for prices).

    Returns:
        A clean dict with the trade data, or None if parsing fails.
    """
    try:
        # Parse the raw JSON string into a Python dictionary
        wrapper = json.loads(raw)

        # The combined stream wraps data in {"stream": "...", "data": {...}}
        # .get("data", wrapper) = use wrapper["data"] if it exists, otherwise
        # use the whole wrapper (handles both stream formats)
        data = wrapper.get("data", wrapper)

        # Skip non-trade events (e.g. subscription confirmations, ping frames)
        # The "e" field = event type. We only want "trade" events.
        if data.get("e") != "trade":
            return None  # return None so the caller knows to skip this message

        # Build our clean trade dictionary
        # We convert price and quantity from strings to floats here
        # (Binance sends them as strings to preserve decimal precision)
        return {
            "symbol":        data["s"],          # e.g. "BTCUSDT"
            "trade_id":      data["t"],           # e.g. 3482910 (unique trade ID)
            "price":         float(data["p"]),    # e.g. 43210.50
            "quantity":      float(data["q"]),    # e.g. 0.00123 (BTC amount)
            "trade_time_ms": data["T"],           # e.g. 1700000001000 (Unix ms)
            "trade_time":    datetime.fromtimestamp(
                                 data["T"] / 1000,    # convert ms → seconds
                                 tz=timezone.utc      # always UTC timezone
                             ).isoformat(),           # e.g. "2024-01-15T10:43:01+00:00"
            "is_buyer_mm":   data["m"],           # True/False
        }

    except (KeyError, ValueError, json.JSONDecodeError) as exc:
        # KeyError   = a field we expected ("s", "p", etc.) was missing
        # ValueError = float() conversion failed (e.g. price was "N/A")
        # JSONDecodeError = the raw string wasn't valid JSON
        log.debug(f"Parse error: {exc} — raw={raw[:80]}")
        return None  # skip bad messages, don't crash the whole producer


# =============================================================================
# WEBSOCKET CALLBACK FUNCTIONS
# =============================================================================
# WebSocketApp calls these functions automatically when events happen.
# We pass them as arguments when creating the WebSocketApp object.

def make_on_message(producer: Producer | None, dry_run: bool):
    """
    Factory function that creates the on_message callback.

    Why a factory function instead of a plain function?
    Because on_message needs access to `producer` and `dry_run`,
    but WebSocketApp only allows callbacks with (ws, message) signature.
    The factory "closes over" producer and dry_run — they become part of
    the returned function's scope.
    This pattern is called a "closure" in Python.
    """
    def on_message(ws, raw):
        """Called by WebSocketApp for every message received from Binance."""

        # Step 1: Parse the raw JSON string into a clean Python dict
        trade = parse_binance_trade(raw)

        # Step 2: Skip if parsing failed (non-trade event or bad data)
        if trade is None:
            return

        # Step 3a: DRY-RUN MODE — just print to console, no Kafka
        if dry_run:
            log.info(
                f"[dry-run]  {trade['symbol']:<10}  "
                f"price={trade['price']:>12,.2f}  "    # right-aligned, comma separator
                f"qty={trade['quantity']:>12.6f}"      # 6 decimal places for small amounts
            )
            stats.tick()
            return

        # Step 3b: PRODUCTION MODE — send to Kafka
        # We use the symbol as the partition key.
        # Kafka hashes the key to decide which partition to write to.
        # Same symbol always → same partition → trades arrive in order per symbol.
        # This is important for Flink which needs events in time order.
        partition_key = trade["symbol"].encode("utf-8")
        # .encode("utf-8") converts the string to bytes — Kafka keys must be bytes

        # Serialize the trade dict to a JSON string, then encode to bytes
        # Kafka messages are always bytes, not Python objects
        value_bytes = json.dumps(trade).encode("utf-8")

        ''' Explicitly set partition based on symbol  get rid of hashing and 
        ensure specific symbols go to specific partitions'''
        # Manual partition assignment — 6 symbols across 6 partitions
        SYMBOL_PARTITION = {
            "BTCUSDT":  0,
            "ETHUSDT":  1,
            "BNBUSDT":  2,
            "SOLUSDT":  3,
            "DOGEUSDT": 4,
            "XRPUSDT":  5,
        }

        producer.produce(
            topic    = TOPIC_NAME,
            key      = partition_key,    # determines partition (BTCUSDT→partition 0, etc.)
            value    = value_bytes,      # the actual trade data
            partition = SYMBOL_PARTITION.get(trade["symbol"], 0),  # explicitly set partition
            callback = delivery_report,  # called when Kafka confirms receipt
        )
        
        ''' Code with hashing-based partitioning: auto-assign partition based on the hash of the key (default behavior)
         but it is creating only 2 partitions instead of 3 because of the hash distribution'''
        # produce() puts the message in an internal buffer (non-blocking)
        # Kafka will actually send it based on linger.ms and batch.size settings
        # producer.produce(
        #     topic    = TOPIC_NAME,
        #     key      = partition_key,    # determines partition (BTCUSDT→partition 0, etc.)
        #     value    = value_bytes,      # the actual trade data
        #     callback = delivery_report,  # called when Kafka confirms receipt
        # )


    


        # poll(0) = non-blocking check: trigger any pending delivery callbacks
        # Without this, delivery_report() would never be called
        # The 0 means "don't wait" — just check if any callbacks are ready
        producer.poll(0)

        # Update our stats counter
        stats.tick()

    return on_message  # return the inner function (the actual callback)


def on_error(ws, error):
    """Called by WebSocketApp when a WebSocket error occurs."""
    log.error(f"WebSocket error: {error}")


def on_close(ws, close_status_code, close_msg):
    """Called by WebSocketApp when the connection closes."""
    log.warning(f"WebSocket closed — code={close_status_code}  msg={close_msg}")
    # The main reconnect loop in main() will reopen the connection


def on_open(ws):
    """Called by WebSocketApp when the connection is first established."""
    symbols_upper = [s.upper() for s in SYMBOLS]
    log.info(f"✓ WebSocket connected — streaming {symbols_upper}")
    log.info("  Receiving live trades from Binance (free, no API key)")


# =============================================================================
# GRACEFUL SHUTDOWN
# =============================================================================

# We store the producer in a global variable so the signal handler can access it
_producer_ref = None

def handle_sigint(sig, frame):
    """
    Called when the user presses Ctrl+C (SIGINT signal).
    Flushes the Kafka producer before exiting to avoid losing buffered messages.
    """
    log.info("Shutting down — flushing remaining messages ...")

    if _producer_ref is not None:
        # flush() blocks until all buffered messages are sent (or timeout)
        _producer_ref.flush(timeout=10)
        log.info(f"✓ Flushed.  Total messages sent: {stats.total:,}")

    log.info("Goodbye!")
    sys.exit(0)  # exit with code 0 = clean exit (not an error)

# Register our handler for the SIGINT signal (Ctrl+C)
# When Python receives SIGINT, it calls handle_sigint instead of crashing
signal.signal(signal.SIGINT, handle_sigint)


# =============================================================================
# MAIN FUNCTION
# =============================================================================

def main():
    """
    Entry point of the producer.
    Sets up Kafka, opens the WebSocket, and runs the event loop.
    """
    global _producer_ref  # allow handle_sigint to access the producer

    # --- Parse command line arguments ---
    parser = argparse.ArgumentParser(
        description="Binance WebSocket → Kafka producer for RTBDP course project"
    )
    parser.add_argument(
        "--dry-run",
        action = "store_true",   # if --dry-run is present, this is True
        help   = "Print trades to console only — no Kafka connection made"
    )
    args = parser.parse_args()

    # --- Set up Kafka (skip in dry-run mode) ---
    producer = None

    if not args.dry_run:
        # Step 1: Wait for Kafka to be ready (important on Windows)
        wait_for_kafka(KAFKA_BOOTSTRAP)

        # Step 2: Create the topic with our custom settings
        create_topic_if_missing(KAFKA_BOOTSTRAP)

        # Step 3: Create the Kafka producer
        producer = make_producer()
        _producer_ref = producer  # save reference for graceful shutdown
        log.info(f"✓ Kafka producer ready — writing to topic '{TOPIC_NAME}'")

    else:
        log.info("DRY-RUN mode — trades will be printed to console only")
        log.info("(No Kafka connection will be made)")

    # --- Open WebSocket ---
    log.info(f"Connecting to Binance WebSocket ...")
    log.info(f"  Symbols: {[s.upper() for s in SYMBOLS]}")

    # Create the WebSocket application with our callbacks
    ws = websocket.WebSocketApp(
        WS_URL,
        on_open    = on_open,
        on_message = make_on_message(producer, args.dry_run),
        on_error   = on_error,
        on_close   = on_close,
    )

    # --- Reconnection loop ---
    # run_forever() blocks and processes WebSocket events.
    # If the connection drops, it returns and we loop back to reconnect.
    reconnect_delay = 5  # seconds to wait before reconnecting

    while True:
        try:
            ws.run_forever(
                ping_interval = 20,   # send a ping every 20 seconds (keeps connection alive)
                ping_timeout  = 10,   # if no pong within 10 seconds, connection is dead
            )
        except KeyboardInterrupt:
            # This catches Ctrl+C if signal handler didn't get it first
            handle_sigint(None, None)
        except Exception as exc:
            log.error(f"Unexpected error in WebSocket loop: {exc}")

        # Flush before reconnecting to avoid losing buffered messages
        if producer is not None:
            producer.flush(timeout=5)

        log.warning(f"Reconnecting in {reconnect_delay} seconds ...")
        time.sleep(reconnect_delay)


# =============================================================================
# ENTRY POINT
# =============================================================================
# This block only runs when you execute: python binance_producer.py
# It does NOT run when this file is imported by another Python file.
# This is a Python best practice for all scripts.

if __name__ == "__main__":
    main()
