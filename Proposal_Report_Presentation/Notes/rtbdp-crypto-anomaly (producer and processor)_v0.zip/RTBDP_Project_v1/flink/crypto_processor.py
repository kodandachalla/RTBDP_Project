# =============================================================================
# PYFLINK STREAM PROCESSOR — Crypto Market Anomaly Detection
# =============================================================================
#
# Pipeline:
#   Kafka "raw-trades"
#       → ParseTradeMap          (JSON string → typed tuple)
#       → filter(not None)       (drop malformed messages)
#       → key_by(symbol)         (split stream per symbol)
#           ├── WashTradeDetector    → anomaly_events (PostgreSQL)
#           ├── PumpDumpDetector     → anomaly_events (PostgreSQL)
#           ├── VolumeSpikeDetector  → anomaly_events (PostgreSQL)
#           ├── 1-min OHLC window    → ohlc_candles  (PostgreSQL)
#           └── 5-min OHLC window    → ohlc_candles  (PostgreSQL)
#
# Run (from project root with venv activated):
#   python flink/crypto_processor.py
#
# Pre-requisites:
#   1. Java 11 installed and JAVA_HOME set
#   2. pip install apache-flink==1.18.0 psycopg2-binary==2.9.9
#   3. Docker containers running  (docker compose up -d)
#   4. Producer running           (python producer/binance_producer.py)
# =============================================================================


# =============================================================================
# IMPORTS
# =============================================================================

import json           # parse Kafka JSON messages into Python dicts
import logging        # structured log output with timestamps
import time           # sleep() while waiting for Kafka topic
from datetime import datetime, timezone  # convert Unix ms → UTC datetime

import psycopg2       # PostgreSQL driver — write results to DB

# PyFlink — core pipeline building blocks
from pyflink.common import WatermarkStrategy, Duration, Time
from pyflink.common.serialization import SimpleStringSchema
from pyflink.common.typeinfo import Types
from pyflink.datastream import StreamExecutionEnvironment, RuntimeExecutionMode
from pyflink.datastream.connectors.kafka import KafkaSource, KafkaOffsetsInitializer
from pyflink.datastream.functions import (
    MapFunction,            # one element in → one element out
    ProcessWindowFunction,  # called once per closed window with all its elements
    KeyedProcessFunction,   # called per element, has access to per-key state
    RuntimeContext,         # passed to open() — used to register state
)
from pyflink.datastream.window import TumblingEventTimeWindows
from pyflink.datastream.state import ValueStateDescriptor, ListStateDescriptor


# =============================================================================
# LOGGING SETUP
# =============================================================================

logging.basicConfig(
    level   = logging.INFO,
    format  = "%(asctime)s  %(levelname)-8s  %(message)s",
    datefmt = "%H:%M:%S",
)
log = logging.getLogger("flink-processor")


# =============================================================================
# CONFIGURATION
# =============================================================================

# Kafka bootstrap — "localhost" because Flink runs on Windows host
# Uses the PLAINTEXT_HOST listener (port 9092) we defined in docker-compose.yml
KAFKA_BOOTSTRAP = "localhost:9092"
KAFKA_TOPIC     = "raw-trades"

# Consumer group ID — Kafka tracks read progress (offsets) per group.
# If Flink restarts, it resumes from where it left off, not from beginning.
KAFKA_GROUP_ID  = "flink-crypto-processor"

# PostgreSQL credentials — must match docker-compose.yml environment section
# PG_HOST     = "localhost"     # localhost because Flink runs on Windows host
PG_HOST     = "127.0.0.1"
PG_PORT     = 5432
PG_DATABASE = "crypto_market"
PG_USER     = "flink"
PG_PASSWORD = "flink_password"

# ── CEP thresholds ────────────────────────────────────────────────────────────
# Tuned to trigger realistically with live Binance data.
# Crypto markets are volatile — thresholds are intentionally sensitive
# so you see alerts during a short demo.

# WASH TRADE: price swing % across last 60 trades
# WASH_PRICE_SWING_PCT    = 0.5   # 0.5% swing — realistic for 30-second window
# # WASH TRADE: current volume vs rolling average
# WASH_VOLUME_MULTIPLIER  = 2.0   # 2× average — common in real markets

# # PUMP & DUMP: minimum rise to enter pump phase
# PUMP_RISE_PCT           = 0.8   # 0.8% rise in under 2 minutes
# # PUMP & DUMP: minimum drop from peak to confirm dump
# PUMP_DROP_PCT           = 0.5   # 0.5% drop in under 4 minutes

# # VOLUME SPIKE: current 10s count vs rolling 10-min average
# VOLUME_SPIKE_MULTIPLIER = 3.0   # 3× average count — noticeable burst


WASH_PRICE_SWING_PCT    = 0.3   # DOGE and XRP swing wildly
WASH_VOLUME_MULTIPLIER  = 1.5
PUMP_RISE_PCT           = 0.4   # easier to trigger on meme coins
PUMP_DROP_PCT           = 0.3
VOLUME_SPIKE_MULTIPLIER = 2.0   # DOGE spikes frequently




# =============================================================================
# SECTION 1 — POSTGRESQL WRITER
# =============================================================================
# Manages the database connection and provides one method per table.
# Each Flink operator (OHLC window, CEP detector) creates its OWN instance
# inside open() — Flink operators can run in parallel tasks.
# =============================================================================

class PGWriter:
    """Handles PostgreSQL connection and all INSERT/UPSERT operations."""

    def __init__(self):
        self.conn = None   # connect lazily on first use

    def connect(self):
        """Open a new PostgreSQL connection."""
        self.conn = psycopg2.connect(
            host     = PG_HOST,
            port     = PG_PORT,
            dbname   = PG_DATABASE,
            user     = PG_USER,
            password = PG_PASSWORD,
        )
        # autocommit = True means every INSERT is immediately visible.
        # Without it we would need conn.commit() after each write.
        self.conn.autocommit = True
        log.info("[postgres] Connected")

    def ensure_connected(self):
        """Reconnect automatically if connection was lost."""
        if self.conn is None or self.conn.closed:
            self.connect()

    def write_ohlc(self, symbol, window_start, window_end, window_size,
                   open_price, high_price, low_price, close_price,
                   trade_volume, trade_count):
        """
        Insert one OHLC candle into the ohlc_candles table.
        Called by OHLCWindowFunction once per closed window per symbol.
        """
        self.ensure_connected()
        sql = """
            INSERT INTO ohlc_candles (
                symbol, window_start, window_end, window_size,
                open_price, high_price, low_price, close_price,
                trade_volume, trade_count
            ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
        """
        with self.conn.cursor() as cur:
            cur.execute(sql, (
                symbol, window_start, window_end, window_size,
                open_price, high_price, low_price, close_price,
                trade_volume, trade_count
            ))

    def write_anomaly(self, symbol, detected_at, pattern_type, severity,
                      price_start, price_end, price_change_pct,
                      volume_ratio, description):
        """
        Insert one anomaly alert into the anomaly_events table.
        Called by each CEP detector when its pattern fires.

        pattern_type: 'WASH_TRADE' | 'PUMP_AND_DUMP' | 'VOLUME_SPIKE'
        severity:     'LOW' | 'MEDIUM' | 'HIGH'
        """
        self.ensure_connected()
        sql = """
            INSERT INTO anomaly_events (
                symbol, detected_at, pattern_type, severity,
                price_start, price_end, price_change_pct,
                volume_ratio, description
            ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)
        """
        with self.conn.cursor() as cur:
            cur.execute(sql, (
                symbol, detected_at, pattern_type, severity,
                price_start, price_end, price_change_pct,
                volume_ratio, description
            ))

    def write_ticker(self, symbol, price, change_pct, volume):
        """
        Upsert latest price into price_ticker table.

        UPSERT means:
          - If no row exists for this symbol → INSERT a new row
          - If a row already exists for this symbol → UPDATE it in place
        This keeps exactly ONE row per symbol at all times.
        Grafana reads this table for the live price stat panels.
        """
        self.ensure_connected()
        sql = """
            INSERT INTO price_ticker (
                symbol, price, price_change_pct, volume_1min, updated_at
            ) VALUES (%s, %s, %s, %s, NOW())
            ON CONFLICT (symbol) DO UPDATE SET
                price            = EXCLUDED.price,
                price_change_pct = EXCLUDED.price_change_pct,
                volume_1min      = EXCLUDED.volume_1min,
                updated_at       = NOW()
        """
        # EXCLUDED refers to the values we tried to INSERT.
        # ON CONFLICT uses them to UPDATE instead.
        with self.conn.cursor() as cur:
            cur.execute(sql, (symbol, price, change_pct, volume))


# =============================================================================
# SECTION 2 — PARSE MAP FUNCTION
# =============================================================================
# First operator in the pipeline after Kafka.
# Converts raw JSON strings into typed Python tuples.
#
# WHY TUPLES?
# Flink needs to know the exact type of each field to serialize data
# efficiently between operators. We declare output_type= when attaching
# this function to the stream (see main()).
#
# Input  (from Kafka):  '{"symbol":"BTCUSDT","price":43210.5,...}'
# Output (to pipeline): ("BTCUSDT", 43210.5, 0.00123, 1700000001000)
# =============================================================================

class ParseTradeMap(MapFunction):
    """Converts raw Kafka JSON string into a (symbol, price, qty, ts_ms) tuple."""

    def map(self, raw_json: str):
        try:
            d = json.loads(raw_json)   # parse JSON string → Python dict
            return (
                d["symbol"],               # str:   "BTCUSDT"
                float(d["price"]),         # float: 43210.5
                float(d["quantity"]),      # float: 0.00123
                int(d["trade_time_ms"]),   # int:   1700000001000 (Unix ms)
            )
        except (KeyError, ValueError, json.JSONDecodeError) as exc:
            log.warning(f"[parse] Bad message skipped: {exc}")
            return None   # will be dropped by .filter(lambda t: t is not None)


# =============================================================================
# SECTION 3 — OHLC WINDOW FUNCTION
# =============================================================================
# Called by Flink ONCE per (symbol, window) pair when the window closes.
#
# WHAT IS A TUMBLING WINDOW?
# A fixed-size, non-overlapping time window.
# Example — 1-minute tumbling window for BTCUSDT:
#   Window 1 collects all BTCUSDT trades from 10:00:00 → 10:01:00
#   Window 2 collects all BTCUSDT trades from 10:01:00 → 10:02:00
#   Each trade belongs to exactly ONE window.
#
# WHY EVENT TIME?
# Trades have a timestamp inside the message (trade_time_ms).
# Event time means: use the timestamp inside the trade, NOT the clock time
# when Flink received it. This is more accurate for financial data.
# =============================================================================

class OHLCWindowFunction(ProcessWindowFunction):
    """Computes an OHLC candle from all trades in a closed window."""

    def __init__(self, window_label: str):
        # window_label = "1min" or "5min"
        # Stored in the DB so Grafana can filter: WHERE window_size = '1min'
        self.window_label = window_label
        self.pg = None   # created in open(), not here

    def open(self, runtime_context):
        # open() runs inside the Flink task (after the JVM is started).
        # Creating the PG connection here (not in __init__) ensures
        # network is available and we are inside the Flink runtime.
        self.pg = PGWriter()
        self.pg.connect()

    def process(self, key: str, context, elements):
        """
        Parameters:
          key      = symbol string, e.g. "BTCUSDT"
          context  = window metadata (start/end timestamps)
          elements = iterable of all trade tuples in this window
        """
        trades = list(elements)   # materialise the Flink iterator
        if not trades:
            return

        # Extract fields from each tuple: (symbol, price, qty, ts_ms)
        prices = [t[1] for t in trades]    # list of all prices
        qtys   = [t[2] for t in trades]    # list of all quantities

        # OHLC computation
        open_price  = prices[0]     # first trade in window
        close_price = prices[-1]    # last trade in window
        high_price  = max(prices)   # highest price in window
        low_price   = min(prices)   # lowest price in window
        volume      = sum(qtys)     # total quantity traded
        trade_count = len(trades)   # number of individual trades

        # Convert window boundaries: Unix ms → UTC datetime objects
        # PostgreSQL TIMESTAMPTZ column accepts Python datetime objects
        window_start = datetime.fromtimestamp(
            context.window().start / 1000, tz=timezone.utc
        )
        window_end = datetime.fromtimestamp(
            context.window().end / 1000, tz=timezone.utc
        )

        try:
            # Write OHLC candle to ohlc_candles table
            self.pg.write_ohlc(
                key, window_start, window_end, self.window_label,
                open_price, high_price, low_price, close_price,
                volume, trade_count
            )

            # Update price ticker with the latest close price
            # change_pct = how much price moved within this window
            change_pct = ((close_price - open_price) / open_price) * 100 \
                         if open_price > 0 else 0.0
            self.pg.write_ticker(key, close_price, change_pct, volume)

            log.info(
                f"[{self.window_label}] {key}  "
                f"O={open_price:.2f}  H={high_price:.2f}  "
                f"L={low_price:.2f}  C={close_price:.2f}  "
                f"vol={volume:.4f}  n={trade_count}"
            )
        except Exception as exc:
            log.error(f"[ohlc] DB write failed: {exc}")

        # Flink requires process() to be a generator.
        # We yield nothing because we write directly to PostgreSQL,
        # not to a downstream Flink stream.
        return
        yield   # makes Python treat this as a generator function


# =============================================================================
# SECTION 4 — CEP PATTERN 1: WASH TRADE DETECTOR
# =============================================================================
# WHAT IS WASH TRADING?
#   A trader buys and sells the same asset to themselves repeatedly.
#   This creates fake trading volume — makes the asset look active when it isn't.
#   It is illegal on regulated markets but very common in crypto.
#
# HOW WE DETECT IT:
#   For each symbol, we keep a rolling history of the last 60 prices and volumes.
#   60 trades at ~2 trades/sec ≈ 30 seconds of data.
#
#   If the price swings up and down more than 0.5% (high - low / low)
#   AND the current trade's volume is >2× the rolling average volume
#   → we flag this as likely wash trading.
#
# FLINK KEY CONCEPT — LIST STATE:
#   KeyedProcessFunction lets us store STATE per key.
#   "Per key" means BTCUSDT gets its own list, ETHUSDT gets its own list, etc.
#   Flink manages state storage — it persists across elements, and is saved
#   to disk during checkpoints (so it survives restarts).
# =============================================================================

class WashTradeDetector(KeyedProcessFunction):

    def open(self, runtime_context: RuntimeContext):
        """Register state descriptors — Flink manages the actual storage."""
        self.pg = PGWriter()
        self.pg.connect()

        # ListState: stores a list of floats per symbol key
        # Flink persists this list between calls to process_element()
        self.price_history = runtime_context.get_list_state(
            ListStateDescriptor("wash_prices", Types.FLOAT())
        )
        self.vol_history = runtime_context.get_list_state(
            ListStateDescriptor("wash_volumes", Types.FLOAT())
        )

    def process_element(self, trade, ctx):
        """Called by Flink for every trade event in the keyed stream."""
        symbol, price, quantity, ts_ms = trade

        # Load existing history from Flink state
        # .get() returns an iterable; "or []" handles the first call (empty state)
        prices  = list(self.price_history.get()  or [])
        volumes = list(self.vol_history.get()    or [])

        # Append current trade values
        prices.append(price)
        volumes.append(quantity)

        # Keep only the last 60 entries — sliding window of ~30 seconds
        # Without this cap the list grows forever and wastes memory
        prices  = prices[-60:]
        volumes = volumes[-60:]

        # Write updated lists back to Flink state
        self.price_history.update(prices)
        self.vol_history.update(volumes)

        # Wait for at least 20 data points before evaluating
        # (prevents false positives on the very first few trades)
        if len(prices) < 20:
            return

        # ── Compute price swing ───────────────────────────────────────────────
        high = max(prices)
        low  = min(prices)
        # swing_pct = how much % the price oscillated across the rolling window
        swing_pct = ((high - low) / low) * 100 if low > 0 else 0.0

        # ── Compute volume ratio ──────────────────────────────────────────────
        avg_vol      = sum(volumes) / len(volumes)
        # volume_ratio = how many times bigger the current trade is vs average
        volume_ratio = quantity / avg_vol if avg_vol > 0 else 0.0

        # ── Check both conditions ─────────────────────────────────────────────
        if swing_pct >= WASH_PRICE_SWING_PCT and volume_ratio >= WASH_VOLUME_MULTIPLIER:

            detected_at = datetime.fromtimestamp(ts_ms / 1000, tz=timezone.utc)
            severity    = "HIGH" if swing_pct > 1.5 else "MEDIUM"
            description = (
                f"Price swung {swing_pct:.2f}% "
                f"(high={high:.2f}, low={low:.2f}) "
                f"with volume {volume_ratio:.1f}x average "
                f"across last {len(prices)} trades"
            )

            try:
                self.pg.write_anomaly(
                    symbol, detected_at, "WASH_TRADE", severity,
                    low, high, swing_pct, volume_ratio, description
                )
                log.warning(f"[CEP] WASH_TRADE {symbol}: {description}")
            except Exception as exc:
                log.error(f"[CEP] wash trade DB error: {exc}")


# =============================================================================
# SECTION 5 — CEP PATTERN 2: PUMP AND DUMP DETECTOR
# =============================================================================
# WHAT IS PUMP & DUMP?
#   Step 1 (PUMP): A group buys an asset to drive the price up quickly.
#   Step 2 (DUMP): They sell all at once while retail investors are buying.
#   Result: Retail investors are left holding an asset that immediately crashes.
#
# HOW WE DETECT IT — STATE MACHINE with 3 phases:
#
#   WATCHING   → normal, tracking current price as baseline
#       ↓ (price rises > 0.8% within 2 minutes)
#   PUMP_CONFIRMED → pump detected, now watching for dump
#       ↓ (price drops > 0.5% from peak within 4 minutes)
#   ALERT FIRED → write anomaly to DB → back to WATCHING
#
# FLINK KEY CONCEPT — VALUE STATE:
#   ValueStateDescriptor stores a SINGLE value per key (not a list).
#   We use 4 separate ValueState objects to track:
#     - which phase we are in
#     - what the baseline price was
#     - when the phase started
#     - what the peak price was
# =============================================================================

class PumpDumpDetector(KeyedProcessFunction):

    def open(self, runtime_context: RuntimeContext):
        self.pg = PGWriter()
        self.pg.connect()

        # Phase tracker: "WATCHING" | "PUMP_CONFIRMED"
        self.phase = runtime_context.get_state(
            ValueStateDescriptor("pd_phase", Types.STRING())
        )
        # Baseline price when we started watching
        self.start_price = runtime_context.get_state(
            ValueStateDescriptor("pd_start_price", Types.FLOAT())
        )
        # Timestamp when we entered current phase (Unix ms)
        self.start_time = runtime_context.get_state(
            ValueStateDescriptor("pd_start_time", Types.LONG())
        )
        # Peak price reached during pump phase
        self.peak_price = runtime_context.get_state(
            ValueStateDescriptor("pd_peak_price", Types.FLOAT())
        )

    def _reset(self, price, ts_ms):
        """Reset state machine to WATCHING with current price as new baseline."""
        self.phase.update("WATCHING")
        self.start_price.update(price)
        self.start_time.update(ts_ms)
        self.peak_price.update(price)

    def process_element(self, trade, ctx):
        symbol, price, quantity, ts_ms = trade

        # Read current state — .value() returns None on first call
        phase       = self.phase.value()       or "WATCHING"
        start_price = self.start_price.value() or price
        start_time  = self.start_time.value()  or ts_ms
        peak_price  = self.peak_price.value()  or price

        # How many milliseconds since we entered the current phase
        elapsed_ms = ts_ms - start_time

        # ── Phase: WATCHING ───────────────────────────────────────────────────
        if phase == "WATCHING":
            # Set current price as baseline and start watching for a pump
            self.start_price.update(price)
            self.start_time.update(ts_ms)
            self.peak_price.update(price)
            self.phase.update("PUMP_CONFIRMED")
            # We immediately move to PUMP_CONFIRMED to start tracking the rise

        # ── Phase: PUMP_CONFIRMED (watching for rise then dump) ───────────────
        elif phase == "PUMP_CONFIRMED":
            # Track the highest price we have seen since baseline
            new_peak = max(peak_price, price)
            self.peak_price.update(new_peak)

            # How much has price risen from baseline to peak?
            rise_pct = ((new_peak - start_price) / start_price) * 100 \
                       if start_price > 0 else 0.0

            # How much has price dropped from peak to current?
            drop_pct = ((new_peak - price) / new_peak) * 100 \
                       if new_peak > 0 else 0.0

            # PUMP detected AND DUMP detected — fire the alert
            if (rise_pct >= PUMP_RISE_PCT and
                drop_pct >= PUMP_DROP_PCT and
                elapsed_ms <= 240_000):   # all within 4 minutes

                detected_at = datetime.fromtimestamp(ts_ms / 1000, tz=timezone.utc)
                severity    = "HIGH" if (rise_pct + drop_pct) > 3.0 else "MEDIUM"
                description = (
                    f"Pump +{rise_pct:.2f}% to {new_peak:.2f}, "
                    f"then dump -{drop_pct:.2f}% to {price:.2f} "
                    f"in {elapsed_ms / 1000:.0f}s"
                )

                try:
                    self.pg.write_anomaly(
                        symbol, detected_at, "PUMP_AND_DUMP", severity,
                        start_price, price, -drop_pct,
                        rise_pct / drop_pct if drop_pct > 0 else 0.0,
                        description
                    )
                    log.warning(f"[CEP] PUMP_AND_DUMP {symbol}: {description}")
                except Exception as exc:
                    log.error(f"[CEP] pump dump DB error: {exc}")

                # Reset after alert — start watching for the next pattern
                self._reset(price, ts_ms)

            elif elapsed_ms > 240_000:
                # 4 minutes passed without completing the pattern — reset
                self._reset(price, ts_ms)


# =============================================================================
# SECTION 6 — CEP PATTERN 3: VOLUME SPIKE DETECTOR
# =============================================================================
# WHAT IS A VOLUME SPIKE?
#   A sudden burst of trading activity far above normal levels.
#   Can signal: flash crash starting, whale executing huge order,
#               coordinated manipulation, breaking news event.
#
# HOW WE DETECT IT:
#   1. Count how many trades arrived in the last 10 seconds (sliding window).
#   2. Keep a rolling 10-minute history of those 10-second counts.
#   3. If current 10-second count > 3× rolling average → VOLUME SPIKE.
#   4. Enforce 30-second cooldown between alerts for the same symbol
#      (avoids spamming the alerts table during extended high-volume periods).
# =============================================================================

class VolumeSpikeDetector(KeyedProcessFunction):

    def open(self, runtime_context: RuntimeContext):
        self.pg = PGWriter()
        self.pg.connect()

        # Rolling history of 10-second trade counts (max 60 = 10 minutes)
        self.count_history = runtime_context.get_list_state(
            ListStateDescriptor("vs_counts", Types.LONG())
        )
        # Timestamps of trades within the current 10-second sliding window
        self.current_window_ts = runtime_context.get_list_state(
            ListStateDescriptor("vs_window_ts", Types.LONG())
        )
        # Unix ms timestamp of last alert (for cooldown)
        self.last_alert_ts = runtime_context.get_state(
            ValueStateDescriptor("vs_last_alert", Types.LONG())
        )

    def process_element(self, trade, ctx):
        symbol, price, quantity, ts_ms = trade

        # ── Build current 10-second sliding window ────────────────────────────
        current = list(self.current_window_ts.get() or [])
        current.append(ts_ms)
        # Keep only timestamps within the last 10 seconds
        current = [t for t in current if ts_ms - t <= 10_000]
        self.current_window_ts.update(current)
        current_count = len(current)   # number of trades in last 10 seconds

        # ── Update rolling 10-minute history ──────────────────────────────────
        history = list(self.count_history.get() or [])
        history.append(current_count)
        history = history[-60:]        # keep last 60 snapshots = 10 minutes
        self.count_history.update(history)

        # Need at least 6 snapshots (1 minute) before making decisions
        # (avoids false positives right after startup)
        if len(history) < 6:
            return

        # ── Check threshold and cooldown ──────────────────────────────────────
        avg_count    = sum(history) / len(history)
        volume_ratio = current_count / avg_count if avg_count > 0 else 0.0
        last_alert   = self.last_alert_ts.value() or 0
        cooldown_ok  = (ts_ms - last_alert) > 30_000   # 30 second cooldown

        if volume_ratio >= VOLUME_SPIKE_MULTIPLIER and cooldown_ok:
            # Update last alert timestamp (starts the cooldown)
            self.last_alert_ts.update(ts_ms)

            detected_at = datetime.fromtimestamp(ts_ms / 1000, tz=timezone.utc)
            severity    = "HIGH" if volume_ratio > 5.0 else "MEDIUM"
            description = (
                f"{current_count} trades in last 10s "
                f"vs avg {avg_count:.1f} "
                f"({volume_ratio:.1f}x normal — 10-min rolling baseline)"
            )

            try:
                self.pg.write_anomaly(
                    symbol, detected_at, "VOLUME_SPIKE", severity,
                    None, price, None, volume_ratio, description
                )
                log.warning(f"[CEP] VOLUME_SPIKE {symbol}: {description}")
            except Exception as exc:
                log.error(f"[CEP] volume spike DB error: {exc}")


# =============================================================================
# SECTION 7 — KAFKA TOPIC READINESS CHECK
# =============================================================================

def wait_for_kafka_topic(bootstrap: str, topic: str,
                         retries: int = 30, delay: int = 5) -> None:
    """
    Block until the Kafka topic exists.

    WHY IS THIS NEEDED?
    The "raw-trades" topic is created by the producer when it first starts.
    If the Flink processor starts before the producer, the topic doesn't
    exist yet and Flink would crash immediately.

    This function polls Kafka every 5 seconds for up to 2.5 minutes.
    If you see "topic not found" messages, just start the producer first.
    """
    from confluent_kafka.admin import AdminClient

    log.info(f"Waiting for Kafka topic '{topic}' to be created ...")
    admin = AdminClient({"bootstrap.servers": bootstrap})

    for attempt in range(1, retries + 1):
        try:
            existing_topics = admin.list_topics(timeout=5).topics
            if topic in existing_topics:
                log.info(f"✓ Topic '{topic}' found — starting Flink pipeline")
                return
            log.warning(
                f"  [{attempt}/{retries}] Topic not found yet. "
                f"Make sure the producer is running."
            )
        except Exception as exc:
            log.warning(f"  [{attempt}/{retries}] Kafka not reachable: {exc}")

        time.sleep(delay)

    raise RuntimeError(
        f"Topic '{topic}' was not found after {retries} attempts.\n"
        "Start the producer first:\n"
        "  cd RTBDP_Project && venv\\Scripts\\activate\n"
        "  python producer/binance_producer.py"
    )


# =============================================================================
# SECTION 8 — MAIN PIPELINE
# =============================================================================

def main():
    """
    Assembles and submits the Flink streaming pipeline.

    KEY CONCEPT — LAZY EXECUTION:
    All the .map(), .filter(), .key_by(), .window(), .process() calls below
    only BUILD a pipeline description — they do not process any data yet.
    The actual execution starts only when env.execute() is called at the end.
    This is called the "builder pattern" and is common in big data frameworks.
    """

    # ── Step 0: Wait for producer to create the topic ─────────────────────────
    wait_for_kafka_topic(KAFKA_BOOTSTRAP, KAFKA_TOPIC)

    # ── Step 1: Create the Flink execution environment ────────────────────────
    env = StreamExecutionEnvironment.get_execution_environment()


    

    # LOAD KAFKA CONNECTOR JAR
    # PyFlink is just a Python wrapper around Java code.
    # To read from Kafka, Flink needs a Java JAR file that contains
    # the actual Kafka connector implementation.
    # Without this JAR, you get the error:
    #   "Could not find Java class KafkaSource"
    # We find the JAR automatically based on where pyflink is installed.
    import os, pyflink
    kafka_jar = os.path.join(
        os.path.dirname(pyflink.__file__),  # path to pyflink folder
        "lib",                               # lib subfolder inside pyflink
        "flink-sql-connector-kafka-4.0.1-2.0.jar"  # the JAR we downloaded
    )
    # add_jars() needs a file URI — "file:///" prefix is required on Windows
    # Replace backslashes with forward slashes (Windows path → URI)
    # Then encode spaces as %20 (Java URI parser rejects spaces)
    kafka_jar_uri = "file:///" + kafka_jar.replace(os.sep, "/").replace(" ", "%20")
    env.add_jars(kafka_jar_uri)










    # STREAMING = process events one by one as they arrive (not batch)
    env.set_runtime_mode(RuntimeExecutionMode.STREAMING)

    # parallelism = how many parallel tasks per operator
    # 1 = single threaded, simplest for a course project on a laptop
    # In production you would use number of CPU cores or Kafka partitions
    env.set_parallelism(1)

    # Checkpoint every 30 seconds:
    # Flink saves all operator state to disk → if it crashes, it restarts
    # from the last checkpoint instead of re-reading all Kafka messages
    env.get_checkpoint_config().set_checkpoint_interval(30_000)

    # ── Step 2: Kafka source ──────────────────────────────────────────────────
    kafka_source = (
        KafkaSource.builder()
        .set_bootstrap_servers(KAFKA_BOOTSTRAP)
        .set_topics(KAFKA_TOPIC)
        .set_group_id(KAFKA_GROUP_ID)
        # latest() = only read messages produced AFTER Flink starts.
        # Use .earliest() if you want to reprocess all historical messages.
        .set_starting_offsets(KafkaOffsetsInitializer.latest())
        # SimpleStringSchema decodes Kafka message bytes → Python str
        .set_value_only_deserializer(SimpleStringSchema())
        .build()
    )

    # ── Step 3: Watermark strategy ────────────────────────────────────────────
    # WHAT ARE WATERMARKS?
    # Flink uses event time (timestamps inside messages) not wall-clock time.
    # Watermarks tell Flink: "all events up to time T have now arrived".
    # When the watermark passes a window's end time, Flink closes that window.
    #
    # for_bounded_out_of_orderness(3 seconds):
    #   "Messages can arrive at most 3 seconds late — wait 3s before closing windows"
    #
    # with_idleness(10 seconds):
    #   "If a Kafka partition sends nothing for 10s, don't let it block windows"
    #   Without this, an idle partition (e.g. BNBUSDT during quiet market)
    #   would prevent ALL windows from ever closing.
    watermark_strategy = (
        WatermarkStrategy
        .for_bounded_out_of_orderness(Duration.of_seconds(3))
        .with_timestamp_assigner(
            # lambda receives: (element, previous_watermark)
            # We return the event timestamp from the tuple (index 3)
            lambda trade, _: trade[3]   # trade[3] = trade_time_ms
        )
        .with_idleness(Duration.of_seconds(10))
    )

    # ── Step 4: Build the pipeline ────────────────────────────────────────────

    # Read raw JSON strings from Kafka
    raw_stream = env.from_source(
        source             = kafka_source,
        watermark_strategy = watermark_strategy,
        source_name        = "Binance Kafka Source"
    )

    # Parse JSON → typed tuples, drop malformed messages
    trade_stream = (
        raw_stream
        .map(
            ParseTradeMap(),
            # Declare output type explicitly — Flink needs this for serialization
            output_type = Types.TUPLE([
                Types.STRING(),   # symbol         e.g. "BTCUSDT"
                Types.FLOAT(),    # price           e.g. 43210.5
                Types.FLOAT(),    # quantity        e.g. 0.00123
                Types.LONG(),     # trade_time_ms   e.g. 1700000001000
            ])
        )
        .filter(lambda t: t is not None)  # drop None from failed parses
        .name("Parse JSON trades")
    )

    # Partition the stream by symbol.
    # After key_by(), each downstream operator maintains state per key.
    # All BTCUSDT trades → same logical sub-stream (and same state bucket).
    # All ETHUSDT trades → their own sub-stream (their own state bucket).
    keyed_stream = trade_stream.key_by(
        lambda trade: trade[0]   # trade[0] = symbol string
    )

    # ── Step 5: Attach CEP detectors ─────────────────────────────────────────
    # Each detector reads from keyed_stream independently.
    # They run in parallel and do not interfere with each other.
    # All write alerts directly to PostgreSQL.
    keyed_stream.process(WashTradeDetector()).name("Wash Trade CEP")
    keyed_stream.process(PumpDumpDetector()).name("Pump and Dump CEP")
    keyed_stream.process(VolumeSpikeDetector()).name("Volume Spike CEP")

    # ── Step 6: 1-minute OHLC tumbling windows ────────────────────────────────
    # TumblingEventTimeWindows.of(Time.minutes(1)):
    #   Creates 1-minute windows based on trade_time_ms (event time).
    #   When a window closes, OHLCWindowFunction.process() is called once
    #   with ALL trades for that symbol in that minute.
    (
        keyed_stream
        .window(TumblingEventTimeWindows.of(Time.minutes(1)))
        .process(
            OHLCWindowFunction("1min"),
            output_type = Types.TUPLE([Types.STRING(), Types.STRING()])
        )
        .name("1-min OHLC Windows")
    )

    # ── Step 7: 5-minute OHLC tumbling windows ────────────────────────────────
    # Same structure, but each window covers 5 minutes.
    # Grafana shows both 1-min and 5-min candles — user picks with a variable.
    (
        keyed_stream
        .window(TumblingEventTimeWindows.of(Time.minutes(5)))
        .process(
            OHLCWindowFunction("5min"),
            output_type = Types.TUPLE([Types.STRING(), Types.STRING()])
        )
        .name("5-min OHLC Windows")
    )

    # ── Step 8: Execute the job ───────────────────────────────────────────────
    # Everything above only DEFINED the pipeline graph.
    # env.execute() compiles it, starts the Flink runtime, and begins processing.
    # For a streaming job this BLOCKS FOREVER — runs until you press Ctrl+C.
    log.info("=" * 60)
    log.info("  Crypto Market Anomaly Detection — Flink Pipeline")
    log.info("=" * 60)
    log.info(f"  Kafka:      {KAFKA_BOOTSTRAP}  topic={KAFKA_TOPIC}")
    log.info(f"  PostgreSQL: {PG_HOST}:{PG_PORT}/{PG_DATABASE}")
    log.info(f"  Windows:    1-min and 5-min OHLC tumbling windows")
    log.info(f"  CEP:        WASH_TRADE | PUMP_AND_DUMP | VOLUME_SPIKE")
    log.info("=" * 60)

    env.execute("Crypto Market Anomaly Detection Pipeline")


# =============================================================================
# ENTRY POINT
# =============================================================================
# This block runs only when you execute:  python flink/crypto_processor.py
# It does NOT run when the file is imported by another module.

if __name__ == "__main__":
    main()
